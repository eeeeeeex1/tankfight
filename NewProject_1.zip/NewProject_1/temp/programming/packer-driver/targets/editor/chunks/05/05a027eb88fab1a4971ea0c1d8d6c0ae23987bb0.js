System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///C:/cocoscreater/NewProject_1/assets/text/tank0.ts at runtime.
      throw new Error(`SyntaxError: D:\cocos\CocosDashboard\file:\C:\cocoscreater\NewProject_1\assets\text\tank0.ts: Unexpected token (22:8)

  20 |     }
  21 |
> 22 |     Vec2.UP=(0,1);
     |         ^
  23 |
  24 |     private onKeyDown(event: EventKeyboard) {
  25 |         switch (event.keyCode) {`);
    }
  };
});
//# sourceMappingURL=05a027eb88fab1a4971ea0c1d8d6c0ae23987bb0.js.map