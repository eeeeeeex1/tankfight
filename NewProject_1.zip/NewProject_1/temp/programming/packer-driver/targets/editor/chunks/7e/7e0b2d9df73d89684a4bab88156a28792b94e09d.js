System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, Collider2D, _dec, _class, _crd, ccclass, TankCollisionHandler;

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Collider2D = _cc.Collider2D;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "82d48WB89BOq7L+XVFivWf9", "CollisionHandler", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Collider2D', 'Contact2DType']);

      ({
        ccclass
      } = _decorator);

      _export("TankCollisionHandler", TankCollisionHandler = (_dec = ccclass('TankCollisionHandler'), _dec(_class = class TankCollisionHandler extends Component {
        onCollisionEnter(other, self) {
          if (other.colliderType === Collider2D.POLYGON) {
            // 停止坦克的移动
            let tankMovement = this.node.getComponent('TankMovement');

            if (tankMovement) {
              tankMovement.stopMoving();
            }
          }
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=7e0b2d9df73d89684a4bab88156a28792b94e09d.js.map