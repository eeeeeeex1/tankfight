System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///C:/cocoscreater/NewProject_1/assets/text/background.ts at runtime.
      throw new Error("SyntaxError: D:cocosCocosDashboard\file:C:cocoscreaterNewProject_1assets\text\background.ts: Missing semicolon. (7:11)\n\n   5 | export class background extends Component {\n   6 |     start() {\n>  7 |         set fillColor (\"FCF2F2\") {\n     |            ^\n   8 |           \n   9 |     \n  10 |             this._fillColor.set(\"FCF2F2\");");
    }
  };
});
//# sourceMappingURL=2cffe01ab9eb7f5e8aa257d4170a451df63418c9.js.map