System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, systemEvent, Input, input, EventMouse, SystemEvent, Node, macro, RigidBody2D, instantiate, Vec2, _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _crd, ccclass, property, Direction, PlayerController;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      systemEvent = _cc.systemEvent;
      Input = _cc.Input;
      input = _cc.input;
      EventMouse = _cc.EventMouse;
      SystemEvent = _cc.SystemEvent;
      Node = _cc.Node;
      macro = _cc.macro;
      RigidBody2D = _cc.RigidBody2D;
      instantiate = _cc.instantiate;
      Vec2 = _cc.Vec2;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "3f685ZuLc5Msp6m5mkxIn4D", "tank0", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Prefab', 'systemEvent', 'Input', 'input', 'EventMouse', 'SystemEvent', 'Node', 'EventKeyboard', 'macro', 'RigidBody2D', 'Vec3', 'instantiate']);

      //import { Bullet } from './Bullet'; // 假设 Bullet 脚本的文件路径和类名为 Bullet
      __checkObsolete__(['Vec2']);

      ({
        ccclass,
        property
      } = _decorator); // 定义方向向量

      Direction = {
        LEFT: new Vec2(-1, 0),
        RIGHT: new Vec2(1, 0),
        UP: new Vec2(0, 1),
        DOWN: new Vec2(0, -1)
      };

      _export("PlayerController", PlayerController = (_dec = ccclass('PlayerController'), _dec2 = property(RigidBody2D), _dec3 = property(Node), _dec(_class = (_class2 = class PlayerController extends Component {
        constructor() {
          super(...arguments);

          _initializerDefineProperty(this, "rigidBody", _descriptor, this);

          _initializerDefineProperty(this, "shootPower", _descriptor2, this);

          //子弹的发射速度
          _initializerDefineProperty(this, "bulletPrefab", _descriptor3, this);

          _initializerDefineProperty(this, "moveSpeed", _descriptor4, this);

          // 调整移动速度
          this.direction = cc.Vec2.ZERO;
          this.currentDirection = Vec2.ZERO;
          this.pressedKeys = new Set();
        }

        start() {
          systemEvent.on(SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);
          systemEvent.on(SystemEvent.EventType.KEY_UP, this.onKeyUp, this);
          input.on(Input.EventType.MOUSE_DOWN, this.onMouseDown, this);
          input.on(Input.EventType.KEY_DOWN, this.keytodirection, this);
          input.on(Input.EventType.KEY_UP, this.directiontokey, this);
        }

        onDestroy() {
          systemEvent.off(SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);
          systemEvent.off(SystemEvent.EventType.KEY_UP, this.onKeyUp, this);
          input.off(Input.EventType.KEY_DOWN, this.keytodirection, this);
          input.off(Input.EventType.KEY_UP, this.directiontokey, this);
        } //运动实现模块


        onKeyDown(event) {
          if (!this.pressedKeys.has(event.keyCode)) {
            this.pressedKeys.add(event.keyCode);
            this.updateDirection();
          }
        }

        onKeyUp(event) {
          if (this.pressedKeys.has(event.keyCode)) {
            this.pressedKeys.delete(event.keyCode);
            this.updateDirection();
          }
        }

        updateDirection() {
          var newDirection = Vec2.ZERO.clone();

          if (this.pressedKeys.has(macro.KEY.w)) {
            newDirection.add(Direction.UP);
          }

          if (this.pressedKeys.has(macro.KEY.s)) {
            newDirection.add(Direction.DOWN);
          }

          if (this.pressedKeys.has(macro.KEY.a)) {
            newDirection.add(Direction.LEFT);
          }

          if (this.pressedKeys.has(macro.KEY.d)) {
            newDirection.add(Direction.RIGHT);
          }

          if (!newDirection.equals(this.currentDirection)) {
            this.currentDirection = newDirection;
            this.updateVelocity();
          } else if (newDirection.equals(Vec2.ZERO)) {
            // 如果没有按键被按下，则停止移动
            this.stopMove();
          }
        }

        updateVelocity() {
          // 计算归一化的速度方向向量
          var velocity = this.currentDirection.clone().multiplyScalar(this.moveSpeed);
          velocity.multiplyScalar(1 / 20); // 打印速度向量的值

          console.log('当前速度向量:', velocity);
          console.log("当前方向： ", this.direction);

          if (this.rigidBody) {
            this.rigidBody.linearVelocity = velocity;
          }
        }

        stopMove() {
          if (!this.currentDirection.equals(Vec2.ZERO)) {
            this.currentDirection = Vec2.ZERO;
            this.rigidBody.linearVelocity = Vec2.ZERO;
          }
        } //检测是否设计鼠标左键按下 触发fireBullet


        onMouseDown(event) {
          if (event.getButton() === EventMouse.BUTTON_LEFT) {
            this.fireBullet();
          }
        } //发射子弹


        fireBullet() {
          var bullet = instantiate(this.bulletPrefab);
          bullet.setParent(this.node);
          bullet.setPosition(this.node.position);
          var rgd = bullet.getComponent(RigidBody2D);
          var speed = this.setbulletspeed().multiply(400);
          rgd.linearVelocity = speed;
        }

        setbulletspeed() {
          var direction = this.node.direction.clone();
          return direction;
        } //坦克方向判断模块
        //坦克方向判断模块
        //坦克方向判断模块
        //keydown赋值方向


        keytodirection(event) {
          switch (event.keyCode) {
            case macro.KEY.a:
              this.direction.x = -1;
              break;

            case macro.KEY.d:
              this.direction.x = 1;
              break;

            case macro.KEY.w:
              this.direction.y = 1;
              break;

            case macro.KEY.s:
              this.direction.y = -1;
              break;

            /*
            case macro.KEY.w && macro.KEY.a:
            this.direction.set(-1, 1);
            break;
            case macro.KEY.w && macro.KEY.d:
            this.direction.set(1, 1);
            break;
            case macro.KEY.s && macro.KEY.a:
            this.direction.set(-1, -1);
            break;
            case macro.KEY.s && macro.KEY.d:
            this.direction.set(1, -1);
            break;
            */
          }
        } //keyup删除方向


        directiontokey(event) {
          switch (event.keyCode) {
            case macro.KEY.a:
            case macro.KEY.d:
              this.direction.x = 0;
              break;

            case macro.KEY.w:
            case macro.KEY.s:
              this.direction.y = 0;
              break;

            /*
            case macro.KEY.w && macro.KEY.a:
            case macro.KEY.w && macro.KEY.d:
            case macro.KEY.s && macro.KEY.a:
            case macro.KEY.s && macro.KEY.d:
            this.direction.set(0, 0);
            break;
            */
          }
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "rigidBody", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "shootPower", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return 500;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "bulletPrefab", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "moveSpeed", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return 5;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=6d66c088ca886d5dbfbdfd827a6dc410b1b0da31.js.map